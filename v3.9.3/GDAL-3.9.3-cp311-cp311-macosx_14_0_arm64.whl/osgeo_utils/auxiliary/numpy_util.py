#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# ******************************************************************************
#
#  Project:  GDAL utils.auxiliary
#  Purpose:  utility functions for gdal-numpy integration
#  Author:   Idan Miara <idan@miara.com>
#
# ******************************************************************************
#  Copyright (c) 2020, Idan Miara <idan@miara.com>
#
#  Permission is hereby granted, free of charge, to any person obtaining a
#  copy of this software and associated documentation files (the "Software"),
#  to deal in the Software without restriction, including without limitation
#  the rights to use, copy, modify, merge, publish, distribute, sublicense,
#  and/or sell copies of the Software, and to permit persons to whom the
#  Software is furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included
#  in all copies or substantial portions of the Software.
#
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
#  OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
#  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
#  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
#  DEALINGS IN THE SOFTWARE.
# ******************************************************************************

import numpy as np

from osgeo import gdal, gdal_array
from osgeo_utils.auxiliary.array_util import ArrayOrScalarLike, ScalarLike


def GDALTypeCodeToNumericTypeCodeEx(buf_type, signed_byte, default=None):
    typecode = gdal_array.GDALTypeCodeToNumericTypeCode(buf_type)
    if typecode is None:
        typecode = default

    if buf_type == gdal.GDT_Byte and signed_byte:
        typecode = np.int8
    return typecode


def GDALTypeCodeAndNumericTypeCodeFromDataSet(ds):
    band = ds.GetRasterBand(1)
    buf_type = band.DataType
    signed_byte = False
    if buf_type == gdal.GDT_Byte:
        band._EnablePixelTypeSignedByteWarning(False)
        signed_byte = (
            band.GetMetadataItem("PIXELTYPE", "IMAGE_STRUCTURE") == "SIGNEDBYTE"
        )
        band._EnablePixelTypeSignedByteWarning(True)
    np_typecode = GDALTypeCodeToNumericTypeCodeEx(
        buf_type, signed_byte=signed_byte, default=np.float32
    )
    return buf_type, np_typecode


def array_dist(
    x: ArrayOrScalarLike, y: ArrayOrScalarLike, is_max: bool = True
) -> ScalarLike:
    if isinstance(x, ScalarLike.__args__):
        return abs(x - y)
    if not isinstance(x, np.ndarray):
        x = np.array(x)
    if not isinstance(y, np.ndarray):
        y = np.array(y)
    diff = np.abs(x - y)
    return np.max(diff) if is_max else np.min(diff)
